package com.myquizapplication;

public class Main{ // Java Assignment Day5

 public static void main(String args[]){
  Game game = new Game();
  game.initGame();
  game.play();

 }
 }