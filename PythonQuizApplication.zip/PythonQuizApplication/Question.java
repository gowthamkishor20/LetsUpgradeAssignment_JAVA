package com.myquizapplication;
import java.util.Scanner;
public class Question{  // Java Assignment Day5
     Scanner s = new Scanner(System.in);
       String question,option1,option2,option3,option4; 
       int correctans,myans;

   public boolean askQuestion(){
    System.out.println(question);
    System.out.println("1. "+option1);
    System.out.println("2. "+option2);
    System.out.println("3. "+option3);
    System.out.println("4. "+option4);
    System.out.println("Please choose an Option"); 
    myans=s.nextInt();  

    if(myans==correctans){
      return true;
  }
  return false;
   }
}
