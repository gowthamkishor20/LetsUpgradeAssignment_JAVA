

public class Game{ // Java Assignment Day5
   
  Question questions[] = new Question[3];
  Player player = new Player();
  public void initGame()
  {
   for(int i=0;i<3;i++){
   questions[i] = new Question();
   }
   questions[0].question="What is a correct syntax to output \"Hello World\" in Python?";
   questions[0].option1="print(\"Hello World\")";
   questions[0].option2="p(\"Hello World\")";
   questions[0].option3="echo(\"Hello World\")";
   questions[0].option4="echo \"Hello World\" ";
   questions[0].correctans=1;

   
   questions[1].question="How do you insert COMMENTS in python code?";
   questions[1].option1="/**This is a comment";
   questions[1].option2="//This is a comment";
   questions[1].option3="/*This is a comment*/";
   questions[1].option4="#This is a comment";
   questions[1].correctans=4;

   questions[2].question="Which one is NOT a legal variable name?";
   questions[2].option1="Myvar";
   questions[2].option2="my_var";
   questions[2].option3="my-var";
   questions[2].option4="_myvar";
   questions[2].correctans=3;

   }
  public void play()
  {
  player.getDetails():
  for(int i=0;i<3;i++){
   boolean current_status=questions[i].askQuestion();
   if(current_status==true){
   System.out.println("You Played well!");
   player.score++;
  }
  else{
  System.out.println("Good try!");
   }
   }
  System.out.println(player.name"'s score is "+player.score);
  }
  
}