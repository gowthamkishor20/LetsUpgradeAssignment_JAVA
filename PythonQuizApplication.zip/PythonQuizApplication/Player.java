package com.myquizapplication;
import java.util.Scanner;
public class Player{  // Java Assignment Day5
   Scanner s = new Scanner(System.in);
   String name;
   int score=0;

  public void getDetails(){
    System.out.println("Enter player name");
    name=sc.next();

  }
  
  
}
